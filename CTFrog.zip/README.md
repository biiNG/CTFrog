# CTFrog
*A CTF platform created by 3 vegetable guys.*

10月11日才正式建立这个库，11月初能写完就算不错了吧……   
我们的网站基于：
* Django
* Python3.7
* Bootstrap3（还没学会）
* ……

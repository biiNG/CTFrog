from django.apps import AppConfig


class AnnouncementConfig(AppConfig):
    name = 'announcement'

def writetest(string):
    with open('1.txt','a') as f:
        f.write('\n'+str(string))